Globus libs go here. Update the current version if you
 are updating the libs. 

Current version 4.0.3