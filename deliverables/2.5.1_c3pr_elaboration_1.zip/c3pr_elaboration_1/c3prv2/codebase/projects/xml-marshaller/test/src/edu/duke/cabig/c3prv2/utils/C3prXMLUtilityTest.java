package edu.duke.cabig.c3prv2.utils;

import junit.framework.TestCase;
import edu.duke.cabig.c3pr.domain.Study;

import java.io.*;


/**
 * This class tests the xml serialization/deserialization library of c3pr
 * @testType unit
 * @author kherm
 */
public class C3prXMLUtilityTest extends TestCase {

    /**
     * Testing serialization of c3pr domain objects
     * using a custom serializer.
     *
     * Testing the deserialization of c3pr domain
     * object from xml.
     */
    public void testUtil() {

        Study study = new Study();
        study.setLongTitleText("test");

        try {
            C3prv2XMLUtility xmlUtil = new C3prv2XMLUtility();

            StringWriter pipedWriter = new StringWriter();
            //make sure serialization works
            assertNotNull(xmlUtil.toXML(study),pipedWriter);

            Study pipedStudy = (Study)xmlUtil.fromXML(new StringReader(xmlUtil.toXML(study)));
            //make sure deserialization works as well
            assertNotNull(pipedStudy);

            //confirm that the serialization works both ways
            assertEquals(study.getLongTitleText(),pipedStudy.getLongTitleText());


        } catch (Exception e) {
            fail(e.getMessage());
        }


    }


}
