package com.sb.cabig.c3pr.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class ProtocolIngestorImpl extends ProtocolIngestorImplBase {

	public ProtocolIngestorImpl() throws RemoteException {
		super();
	}

	public void createProtocol(protocol.Protocol protocols) throws RemoteException, com.sb.cabig.c3pr.stubs.types.ProtocolIngestionException {
        {
        System.out.println("Protocol Recived with ID" + protocols.getId());
        System.out.println("");
        }
	}

}

