/*
 * Created on Oct 25, 2006
 */
package edu.duke.cabig.c3prv2.dataload;

/**
 * This is just an example class.  Please delete it.
 * @author Patrick McConnell
 */
public class Dummy
{
	{ // let any developer that even loads this class that it should be deleted
		System.out.println("Please delete edu.duke.cabig.c3prv2.dataload.Dummy");
	}
	
	/**
	 * An example constructor
	 */
	public Dummy()
	{
		super();
	}

	/**
	 * And example method
	 * @return "please delete me"
	 */
	public String dummy()
	{
		return "please delete me";
	}
}
