package edu.duke.cabig.c3pr.domain;

/**
 * @author Rhett Sutphin
 */
public interface Named {
    String getName();
    void setName(String name);
}
