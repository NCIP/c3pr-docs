package edu.duke.cabig.c3pr.utils;

import java.lang.*;

public class IteratorException extends Exception{
  public IteratorException(String s) {
    super(s);
  }

}