package edu.duke.cabig.c3pr;

/**
 * @author Rhett Sutphin
 */
public interface UseCase {
    int getMajor();

    int getMinor();

    String getTitle();
}
