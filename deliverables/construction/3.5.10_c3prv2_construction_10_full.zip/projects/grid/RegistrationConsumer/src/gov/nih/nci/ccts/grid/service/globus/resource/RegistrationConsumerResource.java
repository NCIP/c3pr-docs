package gov.nih.nci.ccts.grid.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this RegistrationConsumerResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class RegistrationConsumerResource extends BaseResourceBase {



}
