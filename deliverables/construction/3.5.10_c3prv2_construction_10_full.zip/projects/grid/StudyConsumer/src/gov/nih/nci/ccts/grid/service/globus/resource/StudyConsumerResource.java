package gov.nih.nci.ccts.grid.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this StudyConsumerResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class StudyConsumerResource extends BaseResourceBase {



}
