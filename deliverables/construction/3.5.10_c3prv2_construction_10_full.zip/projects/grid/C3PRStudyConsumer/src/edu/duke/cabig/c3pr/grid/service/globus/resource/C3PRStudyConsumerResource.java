package edu.duke.cabig.c3pr.grid.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this C3PRStudyConsumerResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class C3PRStudyConsumerResource extends BaseResourceBase {



}
