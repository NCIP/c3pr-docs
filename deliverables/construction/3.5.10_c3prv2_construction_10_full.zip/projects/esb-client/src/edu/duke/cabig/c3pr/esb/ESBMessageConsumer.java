package edu.duke.cabig.c3pr.esb;

public interface ESBMessageConsumer {
	public void processMessage(String message);
}
