
package org.gridlab.gridsphere.extras.services.poll;


public class PollUsers{

    public String userId;
    String oid;


    public PollUsers(){
    }

    public PollUsers(String userId){
        this.userId = userId;
    }

    public String getUserId(){
        return userId;
    }

    public void setUserId(String userId){
        this.userId = userId;
    }

    public String getOid(){
        return oid;
    }

    public void setOid(String oid){
        this.oid = oid;
    }

}