
package org.gridlab.gridsphere.extras.services.poll;


import org.gridlab.gridsphere.portlet.service.PortletService;

import java.util.List;


public interface PollService extends PortletService{



     public Poll getPollByOid(String oid) ;

     public void addPoll(Poll poll);

     public void deletePoll(Poll poll) ;

     public void savePoll(Poll poll);

     public List getPolls();

}