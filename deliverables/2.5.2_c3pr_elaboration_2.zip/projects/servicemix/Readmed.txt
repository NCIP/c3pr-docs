Project conatins the c3prv2 JBI/ESB implementation.
Current implementation is with servicemix version 3

