package edu.duke.cabig.c3pr.gridnode.service;

import java.rmi.RemoteException;

/** 
 * TODO:I am the service side implementation class.  IMPLEMENT AND DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class StudyIngestorImpl extends StudyIngestorImplBase {

	
	public StudyIngestorImpl() throws RemoteException {
		super();
	}
	
	public void createStudy(edu.duke.cabig.c3pr.grid.Study study) throws RemoteException {

        //echo
        System.out.println(study.getId());
                }

}

