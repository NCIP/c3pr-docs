package edu.duke.c3pr.grid;

import edu.duke.cabig.c3pr.gridnode.client.StudyIngestorClient;
import edu.duke.cabig.c3pr.domain.Study;


/**
 * Test class to create a proxy and send a request
 * to the Gridnode
 * 
 * Created by IntelliJ IDEA.
 * User: kherm
 * Date: Dec 15, 2006
 * Time: 7:12:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class SecureTestClient extends TestCase {




    private final String localServiceURL = "https://localhost:8443/wsrf/services/sb/ProtocolIngestor";

    public void testSecureService(){

        try {
            GlobusCredential creds = getProxy("kherm","");

            System.out.println(creds.getIdentity());

            StudyIngestorClient client = new StudyIngestorClient(localServiceURL,creds);

            Study dummyStudy = new Study();
            dummyStudy.setId("test");

            client.createStudy(dummyStudy);
        } catch (Exception e) {
            System.out.println("failing" + e.getMessage());
            fail(e.getMessage());
        }

    }

    public GlobusCredential getProxy(String username, String password) throws Exception{

        String dorianUrl =
                "https://cagrid-dorian.nci.nih.gov:8443/wsrf/services/cagrid/Dorian";
        String authUrl =
                "https://cagrid-auth.nci.nih.gov:8443/wsrf/services/cagrid/AuthenticationService";

        AuthenticationServiceClient client = new AuthenticationServiceClient(
                authUrl);

        BasicAuthenticationCredential bac = new
                BasicAuthenticationCredential();
        bac.setUserId(username);
        bac.setPassword(password);
        Credential cred = new Credential();
        cred.setBasicAuthenticationCredential(bac);
        String xml = client.authenticate(cred).getXml();
        System.out.println(xml.toString());

        ProxyLifetime lifetime = new ProxyLifetime();
        lifetime.setHours(12);
        lifetime.setMinutes(0);
        lifetime.setSeconds(0);

        DorianClient dClient = new DorianClient(dorianUrl);
        KeyPair pair = KeyUtil.generateRSAKeyPair512();
        PublicKey key = new PublicKey(
                KeyUtil.writePublicKey(pair.getPublic()));
        SAMLAssertion saml2 = new SAMLAssertion(xml);

        gov.nih.nci.cagrid.dorian.bean.X509Certificate list[] =
                dClient.createProxy(saml2, key, lifetime, new DelegationPathLength(0));
        X509Certificate[] certs = new X509Certificate[list.length];
        for (int i = 0; i < list.length; i++) {
            certs[i] = CertUtil.loadCertificate(list[i]
                    .getCertificateAsString());
        }
        GlobusCredential gridCred = new GlobusCredential(pair
                .getPrivate(), certs);
        return gridCred;

    }


}

}
