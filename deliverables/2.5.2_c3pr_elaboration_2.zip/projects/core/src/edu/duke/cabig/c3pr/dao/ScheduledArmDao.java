package edu.duke.cabig.c3pr.dao;


/**
 * 
 * @author Kruttik
 * @version 1.0
 */

public interface ScheduledArmDao extends BaseDao{
	
}

