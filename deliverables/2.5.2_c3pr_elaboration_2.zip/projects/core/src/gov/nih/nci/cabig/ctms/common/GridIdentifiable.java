package gov.nih.nci.cabig.ctms.common;

public interface GridIdentifiable {

    public String getGridIndentifier();
    
    public String setGridIdentifier(String gridID);
}
