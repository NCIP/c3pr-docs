$Id: README.txt,v 1.1.1.1 2007/02/01 20:05:42 kherm Exp $

This directory contains all the third-party libraries required for the compilation/deployment of GridSphere. All licenses are open source and cann be found in the licenses directory.





